# PS3 Zone

Plantilla estática de catálogo para recursos comunitarios de PlayStation 3.

## Estructura
- `index.html`: página principal.
- `juegos.html`, `mods.html`, `homebrew.html`, `herramientas.html`: categorías.
- `buscar.html`: búsqueda.
- `detalle.html`: ficha individual por `?id=...`.
- `css/`: estilos, incluido un archivo con ajustes conservadores para navegador de PS3.
- `js/catalogo.js`: datos que consume el prototipo.
- `data/catalogo.json`: copia de datos estructurados para mantenimiento.

## Uso
Publica la carpeta en un alojamiento estático y abre `index.html` desde la URL publicada. No abras con `file://` si el navegador bloquea funciones del sitio.

## Importante
- Las entradas de ejemplo no están marcadas como verificadas.
- Los enlaces externos pueden cambiar, requerir inicio de sesión o no ser compatibles con el navegador de PS3.
- Añade solamente archivos que tengas derecho a distribuir y enlaza fuentes oficiales.
- El catálogo JavaScript (`js/catalogo.js`) es la fuente usada por la interfaz inicial; actualiza también `data/catalogo.json` para mantener ambos datos sincronizados.
