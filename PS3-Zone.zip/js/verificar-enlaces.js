/*
 * Aviso: este archivo es una guía, no una comprobación automática.
 * Los navegadores suelen bloquear solicitudes entre dominios (CORS), y un
 * servidor puede responder de forma distinta a una descarga directa.
 * Comprueba cada URL manualmente en el alojamiento y, cuando sea posible, en PS3.
 */
window.PS3ZoneLinkCheck = {
  status: "manual",
  note: "No marcar enlaces como verificados sin abrirlos y comprobar destino, archivo y compatibilidad."
};