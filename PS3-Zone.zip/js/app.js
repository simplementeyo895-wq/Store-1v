(function(){
  "use strict";
  function escapeHtml(value){return String(value==null?"":value).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
  function card(item){
    return '<article class="resource-card"><span class="tag">'+escapeHtml(item.categoria)+'</span><h3>'+escapeHtml(item.nombre)+'</h3><p>'+escapeHtml(item.descripcion)+'</p><p class="status">Estado del enlace: pendiente de comprobación</p><div class="card-actions"><a href="detalle.html?id='+encodeURIComponent(item.id)+'">Ver detalles</a><a href="'+escapeHtml(item.pagina)+'" target="_blank" rel="noopener">Abrir fuente</a></div></article>';
  }
  function render(target,items){
    var el=document.getElementById(target); if(!el)return;
    if(!items.length){el.innerHTML='<p class="empty-state">No hay elementos que coincidan.</p>';return;}
    el.innerHTML=items.map(card).join("");
  }
  var all=window.PS3ZoneCatalog||[];
  var path=(location.pathname.split("/").pop()||"index.html").toLowerCase();
  if(path==="index.html"||path===""){render("featured",all.slice(0,3));}
  else if(path==="juegos.html"){render("catalog",all.filter(function(x){return x.categoria==="juegos";}));}
  else if(path==="mods.html"){render("catalog",all.filter(function(x){return x.categoria==="mods";}));}
  else if(path==="homebrew.html"){render("catalog",all.filter(function(x){return x.categoria==="homebrew";}));}
  else if(path==="herramientas.html"){render("catalog",all.filter(function(x){return x.categoria==="herramientas";}));}
})();