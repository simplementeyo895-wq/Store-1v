/* Filtros sencillos para las páginas de categorías. */
window.PS3ZoneFilters = {
  byCategory:function(items,category){return (items||[]).filter(function(item){return item.categoria===category;});}
};