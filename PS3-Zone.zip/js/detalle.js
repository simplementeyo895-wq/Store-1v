(function(){
  "use strict";
  function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
  var id=new URLSearchParams(location.search).get("id");
  var item=(window.PS3ZoneCatalog||[]).filter(function(x){return x.id===id;})[0];
  var root=document.getElementById("detail");
  if(!root)return;
  if(!item){root.innerHTML='<h1>Recurso no encontrado</h1><p>Vuelve al catálogo y elige una entrada existente.</p><a class="button" href="buscar.html">Abrir catálogo</a>';return;}
  root.innerHTML='<p class="eyebrow">'+esc(item.categoria)+'</p><h1>'+esc(item.nombre)+'</h1><div class="detail-layout"><div><img class="detail-image" src="'+esc(item.imagen)+'" alt="Imagen de '+esc(item.nombre)+'"></div><div><p>'+esc(item.descripcion)+'</p><ul class="meta-list"><li><strong>Región:</strong> '+esc(item.region)+'</li><li><strong>Versión:</strong> '+esc(item.version)+'</li><li><strong>Formato:</strong> '+esc(item.formato)+'</li><li><strong>Enlace:</strong> Pendiente de comprobación</li></ul><p><a class="button" href="'+esc(item.pagina)+'" target="_blank" rel="noopener">Abrir página del proyecto</a></p><p><a href="buscar.html">← Volver al catálogo</a></p></div></div>';
})();