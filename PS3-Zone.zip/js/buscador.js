(function(){
  "use strict";
  function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
  var params=new URLSearchParams(window.location.search);
  var q=(params.get("q")||"").trim();
  var input=document.getElementById("q"); if(input)input.value=q;
  var list=(window.PS3ZoneCatalog||[]).filter(function(x){
    var hay=(x.nombre+" "+x.categoria+" "+x.descripcion+" "+x.region).toLowerCase();
    return !q||hay.indexOf(q.toLowerCase())!==-1;
  });
  var summary=document.getElementById("search-summary");
  if(summary)summary.textContent=q?'Resultados para "'+q+'": '+list.length:'Todos los recursos: '+list.length;
  var target=document.getElementById("catalog");
  if(target){
    target.innerHTML=list.length?list.map(function(x){
      return '<article class="resource-card"><span class="tag">'+esc(x.categoria)+'</span><h3>'+esc(x.nombre)+'</h3><p>'+esc(x.descripcion)+'</p><p class="status">Enlace pendiente de comprobación</p><div class="card-actions"><a href="detalle.html?id='+encodeURIComponent(x.id)+'">Ver detalles</a><a href="'+esc(x.pagina)+'" target="_blank" rel="noopener">Abrir fuente</a></div></article>';
    }).join(""):'<p class="empty-state">No se encontraron recursos. Prueba otra palabra.</p>';
  }
})();