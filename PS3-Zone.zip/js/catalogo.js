/* Catálogo local: se usa un arreglo JS para que el prototipo también funcione
   si el servidor no permite cargar JSON mediante file://. */
window.PS3ZoneCatalog = [
  {
    id:"ps3hen", nombre:"PS3HEN", categoria:"herramientas", tipo:"homebrew",
    region:"Todas", version:"Consultar proyecto", formato:"Proyecto y paquetes según versión",
    descripcion:"Herramienta para habilitar homebrew en modelos compatibles. Revisa cuidadosamente las instrucciones y compatibilidad.",
    imagen:"assets/img/sin-portada.png", pagina:"https://github.com/PS3Xploit/PS3HEN",
    descarga:"https://github.com/PS3Xploit/PS3HEN", enlace_comprobado:false
  },
  {
    id:"webman-mod", nombre:"webMAN MOD", categoria:"herramientas", tipo:"utilidad",
    region:"Todas", version:"Consultar versiones publicadas", formato:"Paquetes del proyecto",
    descripcion:"Utilidad de administración para PS3 modificadas. Comprueba la compatibilidad con tu configuración.",
    imagen:"assets/img/sin-portada.png", pagina:"https://github.com/aldostools/webMAN-MOD",
    descarga:"https://github.com/aldostools/webMAN-MOD", enlace_comprobado:false
  },
  {
    id:"ps3-homebrew-projects", nombre:"Proyectos homebrew para PS3", categoria:"homebrew", tipo:"colección",
    region:"Todas", version:"Varía por proyecto", formato:"Consultar cada proyecto",
    descripcion:"Repositorio comunitario para explorar proyectos homebrew. Lee las licencias y las instrucciones antes de instalar.",
    imagen:"assets/img/sin-portada.png", pagina:"https://github.com/utkuhalis/ps3-homebrew",
    descarga:"https://github.com/utkuhalis/ps3-homebrew", enlace_comprobado:false
  },
  {
    id:"aldostools-resources", nombre:"Recursos de aldostools", categoria:"herramientas", tipo:"recursos",
    region:"Todas", version:"Varía por recurso", formato:"Consultar cada recurso",
    descripcion:"Repositorio de recursos relacionados con utilidades de PS3. Comprueba cada archivo y su procedencia.",
    imagen:"assets/img/sin-portada.png", pagina:"https://github.com/aldostools/Resources",
    descarga:"https://github.com/aldostools/Resources", enlace_comprobado:false
  },
  {
    id:"gta-127-source", nombre:"Proyecto GTA V 1.27", categoria:"mods", tipo:"código fuente",
    region:"Depende del proyecto", version:"Consultar repositorio", formato:"Código fuente; no es un instalador universal",
    descripcion:"Proyecto para estudiar código relacionado con GTA V. No garantiza compatibilidad ni incluye necesariamente un mod instalable.",
    imagen:"assets/img/sin-portada.png", pagina:"https://github.com/xiBryanDev/GTA-1.27",
    descarga:"https://github.com/xiBryanDev/GTA-1.27", enlace_comprobado:false
  }
];
